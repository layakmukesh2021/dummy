

    <div class="main">

        <div class="container">
            <div class="signup-content">
               
                    
                   
                
                <div class="signup-form">
                  <?php

                    echo form_open_multipart('editproduct/'.$product['id']);

                  ?>

                  <div style="text-align: center;">
                        <h4 style="padding-top: 25px">EDIT PRODUCT</h4>
                  </div>

                        <div class="form-row">

                            <div class="form-group">
                                <div class="form-input">
                                    <label for="Name" class="required">Product Name</label>
                                    <input  type="text" name="name" id="name"  class="form-control" value="<?php echo  $product['prdt_name']; ?>"  required="" />
                                </div>
                                <div class="form-input">
                                    <label for="Address" class="required">Quantity</label>
                                    <input type="text" name="qty" id="qty" class="form-control" required="" value="<?php echo  $product['prdt_quantity']; ?>" />
                                </div>
                               
                             
                               
                            </div>
                            <div class="form-group">

                                <div class="form-input">
                                    <label for="unitprice" class="required">Unit Price(In $)</label>
                                    <input type="text" name="unitprice" id="unitprice" class="form-control" required="" value="<?php echo  $product['unit_price']; ?> "/>
                                </div>
                               
                             <div class="form-select">
                                    <div class="label-flex">
                                        <label for="tax">Tax (In %)</label>
                                       
                                    </div>

<?php
if($product['tax_percentage']=='0')
{

?>


                                    <div class="select-list">
                                        <select name="tax"  id="tax" class="form-control"  required="">
                                            <option value="">Select Tax Percentage </option>

                                            <option value="0" selected>0</option>
                                            <option value="1">1</option>
                                            <option value="5">5</option>
                                            <option value="10">10</option>
                                        </select>
                                    </div>

<?php

}

else if($product['tax_percentage']=='1')
{

?>



   <div class="select-list">
                                        <select name="tax"  id="tax" class="form-control"  required="">
                                            <option value="">Select Tax Percentage </option>

                                            <option value="0">0</option>
                                            <option value="1" selected>1</option>
                                            <option value="5">5</option>
                                            <option value="10">10</option>
                                        </select>
                                    </div>


<?php

}

else if($product['tax_percentage']=='5')
{

?>


 <div class="select-list">
                                        <select name="tax"  id="tax" class="form-control"  required="">
                                            <option value="">Select Tax Percentage </option>

                                            <option value="0">0</option>
                                            <option value="1">1</option>
                                            <option value="5" selected>5</option>
                                            <option value="10">10</option>
                                        </select>
                                    </div>


<?php

}

else if($product['tax_percentage']=='10')
{

?>

 <div class="select-list">
                                        <select name="tax"  id="tax" class="form-control"  required="">
                                            <option value="">Select Tax Percentage </option>

                                            <option value="0">0</option>
                                            <option value="1">1</option>
                                            <option value="5">5</option>
                                            <option value="10" selected>10</option>
                                        </select>
                                    </div>
<?php

}

?>



                                </div> 
                               
                              <!--   <div class="form-input">
                                    <label for="Image">Store Logo</label>
                                    <input class="scrollable" name="image" id="image" type="file" required="" placeholder="" class="form-control"/>
                                </div> -->
                                
                                   
                            </div>
                        </div>
                    
                        <div class="form-submit">
                            <input type="submit" value="Submit" class="submit" id="submit" name="submit" />
                          
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>




<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<script type="text/javascript">
$('#phone').on('keyup',function(){
var phone = $('#phone').val();
var phonelen=phone.length;

if(phonelen>"10")
{


   
   document.getElementById("mob").style.display = "block";
   
  


}
else
{
    document.getElementById("mob").style.display = "none";
   

}


});


$('#contact').on('keyup',function(){
var contact = $('#contact').val();
var contactlen=contact.length;

if(contactlen>"10")
{


   
   document.getElementById("contacts").style.display = "block";
   
  


}
else
{
    document.getElementById("contacts").style.display = "none";
   

}


});


</script>
