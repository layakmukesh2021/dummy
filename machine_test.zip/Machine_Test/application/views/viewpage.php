<!DOCTYPE html>
<html>
<head>
<style>
.button {
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.button1 {background-color: #4CAF50;} /* Green */
.button2 {background-color: #008CBA;} /* Blue */
</style>
</head>
<body style="background-color: #dff0ef">

<div class="container-fluid" style="margin-top: 10px">

<div class="row">
        <div class="col-xl-12">
          <div class="card">
            <div class="card-header border-0">
              <div class="row align-items-center">
                <div class="col">
                  <h3 class="mb-0" style="text-align: center;">Dashboard</h3>
                </div>
              
              </div>
            </div>


<center>

<a href="<?php echo site_url('SiteController/addproducts');?>" class="button button1">Add Product</a>

<a href="<?php echo site_url('SiteController/generatebill');?>" class="button button2">Generate Bill</a>

</center>
</div></div></div></div>


</body>
</html>