<!DOCTYPE html>
<html>
<head>




<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
  overflow:scroll;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}


.button {
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}

.button1 {background-color: #4CAF50;} /* Green */
.button2 {background-color: #008CBA;} /* Blue */



/*tr:nth-child(even) {
  background-color: #dddddd;
}*/
</style>
</head>
<body>

<h2 style="text-align: center;color: #000000">PRODUCT DETAILS</h2>
<center>

<a href="<?php echo site_url('SiteController/home');?>"  class="button button1" >Home</a>

<a href="<?php echo site_url('SiteController/products_reg');?>"  class="button button1" >Add Product</a>

<table class="col-md-8">

  <tr>
    <th>Sl No</th>

    <th>Product Name</th>
    <th>Quantity</th>
    <th>Unit Price</th>
    <th>Tax Percentage</th>
   
    <th>Actions</th>
  </tr>



  <?php

  if(count($val)==0){

    ?>
                      <tr>
                      <td colspan="6" style="color:red" align="center"><h3>No data found</h3></td>
                      </tr>
                      <?php
                     }
                     $i=1;
                     foreach($val as $rows)
                     {

                       $id=$rows['id'];
                       $prdt_name=$rows['prdt_name'];
                       $prdt_quantity=$rows['prdt_quantity'];
                       $unit_price=$rows['unit_price'];
                       $tax_percentage=$rows['tax_percentage'];
                     
                      ?>


  <tr>
    <td><?php echo $i; ?></td>
    <td><?php echo $prdt_name; ?></td>
    <td><?php echo $prdt_quantity; ?></td>
    <td><?php echo $unit_price; ?></td>
    <td><?php echo $tax_percentage; ?></td>
    
      <!--  <td><img src="<?php //echo base_url()."uploads/".$image;?>" width="100" height="100"/></td> -->
    <td>
     
<span class="input-group-append"><a style="text-decoration: none;" href="<?php echo site_url('editproduct/'.$id);?>">  
                EDIT
    </a></span>&nbsp;&nbsp;&nbsp;&nbsp;



<button onclick="deletedata(<?php echo $id;?>)" id="<?php echo $id;?>" value="<?php echo $id;?>">Delete</button>


    </td>
  </tr>
 

<?php
$i++;
}

?>



</table>
</center>
</body>
</html>


<script type="text/javascript">
    var url="<?php echo site_url();?>";
    function deletedata(id){

  //  alert(id);

       var r=confirm("Do you want to delete ?")
        if (r==true)
          window.location = url+"/SiteController/del_data/"+id;
        else
          return false;
        }
</script>