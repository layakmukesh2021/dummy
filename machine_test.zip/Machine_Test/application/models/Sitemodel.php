<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Sitemodel extends CI_Model
{


  public function add_details($info)
  {
    $res=$this->db->insert('product_tbl',$info);
   // $this->db->last_query();
   // exit;
    return $this->db->insert_id();
  }


 public function add_bill_details($info)
  {

   // $this->db->select('product_tbl.prdt_name as prdtname');
   
    $res=$this->db->insert('bill_tbl',$info);
    // $this->db->last_query();
    // exit;
    return $this->db->insert_id();
  }

 public function add_invoice_details($info)
  {

   // $this->db->select('product_tbl.prdt_name as prdtname');
   
    $res=$this->db->insert('invoice_tbl',$info);
    // $this->db->last_query();
    // exit;
    return $this->db->insert_id();

  // $res=$this->db->set('bill_status','0'); 
  //  return  $this->db->update('bill_tbl',$info) ; 



  }



 public function get_lastbill_no()
 {

    $this->db->select('max(bill_no) as maxcode');
    $this->db->from('invoice_tbl');
    $query = $this->db->get(); 
    return $query->row_array(); 

 }





public function get_product_price($proid)
{
    $this->db->where('id',$proid);
  //  $this->db->where('partner_id',$channel);
    $query=$this->db->get('product_tbl');
   //return  $this->db->last_query();
    return $query->result();
}





public function get_product_details()
{
   // $this->db->where('id',$proid);
  //  $this->db->where('partner_id',$channel);
   $this->db->join('product_tbl','product_tbl.id=bill_tbl.product_name','left');
   $this->db->where('bill_status',1);
    $query=$this->db->get('bill_tbl');
   //return  $this->db->last_query();
    return $query->result_array();
}



public function get_bill_invoice_details()
{
   // $this->db->where('id',$proid);
  //  $this->db->where('partner_id',$channel);
   $this->db->join('bill_tbl','bill_tbl.bill_no= invoice_tbl.bill_no','left');
  // $this->db->where('bill_status',1);
    $query=$this->db->get('invoice_tbl');
   //return  $this->db->last_query();
    return $query->result_array();
}

public function get_pro_invoice_details()
{
   
    $this->db->join('product_tbl','product_tbl.id=bill_tbl.product_name','left');
    $query=$this->db->get('bill_tbl');
   //return  $this->db->last_query();
    return $query->result_array();
}



public function getstoreByID($id){
    $this->db->where('id',$id);
    $query=$this->db->get('product_tbl');
    return $query->row_array();
  }

public function updatestore($data,$id){
    $this->db->where('id',$id);
    return $this->db->update('product_tbl',$data);
  }


public function delete_data($id)
  {
    $this->db->where('id',$id);
    return $this->db->delete('product_tbl');
  }


public function checkusername_password($username,$password){
  $this->db->where('username',$username);
  
  $this->db->where('password',$password);
  
  $query=$this->db->get('login_tbl');
  return $query->num_rows();
}


public function loginuser($username,$password){
  $this->db->select('id,username,password');
    $this->db->from('login_tbl');
      $this->db->where('username',$username);
 
    $this->db->where('password',$password);
    $this->db->limit(1);
    $query=$this->db->get();
    //echo $this->db->last_query();exit;
    if($query->num_rows()==1)
    {
    $row=$query->row();
    $data=array(
                 'userloginid'=>$row->id,
                 'loginname'=>$row->username,
          
            );
    $this->session->set_userdata($data);
        //echo $this->session->userdata('userid') ;
    return true;  
    }
    else
    {
      return false;
    }
}



  public function get_product_lists()
    {
        $this->db->order_by('prdt_name');
        $query = $this->db->get('product_tbl');
        return $query->result_array();
    }




  public function display_data()
  {


  // $id= $this->session->userdata('userloginid');

    // exit;

   // $this->db->where('id',$id);
  
   $value=$this->db->get('product_tbl');

    // $this->db->last_query();
    // exit;
   return $value->result_array();
   
  }


 
}





?>